# Servicio Web - Registro e Inicio de Sesión

Este proyecto contiene una API REST construida con Node.js y Express para registrar e iniciar sesión de usuarios.

## Endpoints

- `POST /api/auth/register`  
  Cuerpo JSON: `{ "username": "usuario", "password": "clave" }`

- `POST /api/auth/login`  
  Cuerpo JSON: `{ "username": "usuario", "password": "clave" }`

## Instrucciones

```bash
npm install
npm start
```

## Desarrollado por  
Kevin Barreto - GA7-220501096-AA5-EV01
