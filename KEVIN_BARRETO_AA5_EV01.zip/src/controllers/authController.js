
// Controlador de autenticación con funciones de registro e inicio de sesión
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const usersPath = path.join(__dirname, '../data/users.json');

function loadUsers() {
  if (!fs.existsSync(usersPath)) return [];
  const data = fs.readFileSync(usersPath);
  return JSON.parse(data);
}

function saveUsers(users) {
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
}

// Registro de usuario
const register = (req, res) => {
  const { username, password } = req.body;
  const users = loadUsers();

  if (users.find(user => user.username === username)) {
    return res.status(400).json({ message: 'El usuario ya existe' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  users.push({ username, password: hashedPassword });
  saveUsers(users);

  res.json({ message: 'Usuario registrado exitosamente' });
};

// Inicio de sesión
const login = (req, res) => {
  const { username, password } = req.body;
  const users = loadUsers();

  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ message: 'Error en la autenticación: usuario no encontrado' });
  }

  const isMatch = bcrypt.compareSync(password, user.password);
  if (!isMatch) {
    return res.status(401).json({ message: 'Error en la autenticación: contraseña incorrecta' });
  }

  res.json({ message: 'Autenticación satisfactoria' });
};

module.exports = { register, login };
